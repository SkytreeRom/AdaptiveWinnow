# AdaptiveWinnow  
A simple implementation of **An Adaptive Improved Winnow Algorithm**.  
## Testing  
Testing Adaptive Winnow Algorithm.	

    main

Testing original Winnow Algorithm in original folder. 

    main_original

## Author  
Yinhao Wang <njwangyh@gmail.com>































































