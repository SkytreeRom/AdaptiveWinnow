a=rand(1,1000);
b=a;
[c,d]=scrambling(a,b);
