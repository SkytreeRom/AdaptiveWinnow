clear;close all;
vein_Curvature_dispplay_index=2;
load('result.mat');
imageout2 = imcomplement(imageout2);
figure(1)
imshow(imageout2);


while 1
    pos=round(ginput(1));
    figure(1)
    imshow(imageout2);
    hold on;
    x=pos(1);
    y=pos(2);
    if searchXY(x,y,main_vein_matrix)
        res=main_vein_matrix;
    else
        for i=1:1:size(sub_vein_left_,3)
            if searchXY(x,y,sub_vein_left_(:,:,i))
                res=sub_vein_left_(:,:,i);
            end
        end
        for i=1:1:size(sub_vein_right_,3)
            if searchXY(x,y,sub_vein_right_(:,:,i))
                res=sub_vein_right_(:,:,i);
            end
        end
    end
    xx=res(:,1);%xx��yyΪҶ��������
    yy=res(:,2);
    xx(xx==0)=[];
    yy(yy==0)=[];
    [yy,index]=sort(yy);%���[xx,yy]��yyΪ������������
    xx=xx(index);
    
    result=figure_out_curvature([yy,xx]);%�ú����������ݸ�ʽΪ[y,x]
    if vein_Curvature_dispplay_index==1
        pos=nearestLocation(x,y,xx,yy);
        disp(['point (',num2str(xx(pos)),',',num2str(yy(pos)),') curvature ',num2str(result(pos))]);
        plot(xx(pos),yy(pos),'*')
    else
        average=sum(result)/size(result,1);
        disp(['average curvature ',num2str(average)]);
        plot(xx,yy,'.')
    end
end
function res=searchXY(x,y,searchData)%searchDataΪ���������Ҷ��������
length=size(searchData,1);
%     for i=1:1:length
%         d=sqrt((searchData(i,1)-x))
%     end
xx=repmat(x,length,1);
yy=repmat(y,length,1);
d=sqrt((searchData(:,1)-xx).^2+(searchData(:,2)-yy).^2);
tem=find(d<10,1);%ȷ��һ����ֵ��
if isempty(tem)
    res=0;
else
    res=1;
end
end
function res=nearestLocation(x,y,xx,yy)
length=size(xx,1);
xrep=repmat(x,length,1);
yrep=repmat(y,length,1);
d=sqrt((xrep-xx).^2+(yrep-yy).^2);
pos=find(d==min(min(d)));
res=pos;
end
% figure('WindowButtonDownFcn',@callBack)
%
%
%  function callBack(hObject,~)
%     mousePos=get(hObject,'CurrentPoint');
%     disp(['You clicked X:',num2str(mousePos(1)),',  Y:',num2str(mousePos(2))]);
%  end