# VeinExtraction  
Using Yuv color space and Canny operator to detect leaf veins.Then using Hough transform to segment main and sub vein in previous results.  
## Testing  
Testing VeinExtraction.	

    main


## Author  
Yinhao Wang <njwangyh@gmail.com>






























































